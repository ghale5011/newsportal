<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('adevertises', function (Blueprint $table) {
            $table->id();
            $table->string('compant_name');
            $table->string('contact_no');
            $table->string('banner');
            $table->date('expire_date');
            $table->string('redirect_link');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('adevertises');
    }
};
